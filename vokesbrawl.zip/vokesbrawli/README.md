ANDROID : https://www.mediafire.com/file/775ijd21sbsyb38/com.projectbsds.v41150.apk/file

## Requirements: ##
1. a brain...

## How to run ##
1. download it 
2. decompress it
3. open the folder and run Core.py

## Change the ip address and port (if needed) in libmeow.js located in the lib folder ##

![image](https://user-images.githubusercontent.com/52799759/147313954-e3185d78-da1b-4c9c-b700-c20c58af8633.png)
