How to use:

put your files in ContentUpdater/Content

run ContentUpdater/Updater.py

after its done run ContentUpdater/Server.py

if you managed to deleted it by accident here what lastversion.txt should contains

41.131.1...c0c588f87983f5bdba538af845af19f9a8d0c740